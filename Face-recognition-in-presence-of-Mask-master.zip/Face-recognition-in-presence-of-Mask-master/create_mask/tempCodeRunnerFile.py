print(mask_path)
